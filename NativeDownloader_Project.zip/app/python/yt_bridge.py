
# placeholder python bridge
def download_with_ytdlp(url, quality, outdir):
    print("Downloading:", url, "Quality:", quality, "Output:", outdir)
